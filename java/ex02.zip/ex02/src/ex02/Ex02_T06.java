package ex02;

public class Ex02_T06 {
	public static void main(String[] args) {
		double pi = Math.PI; // 3.141593
		System.out.format("圓周率為%010f%n", pi);
		System.out.format("圓周率為%.3f%n", pi);
		System.out.format("圓周率為%.0f%n", pi);
	}
}
