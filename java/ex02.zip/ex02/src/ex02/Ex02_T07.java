package ex02;

public class Ex02_T07 {

	public static void main(String[] args) {
		int i = 50;
		i += 100 % 10 + 5 * 4;
		System.out.printf("i 變數值 = %d", i);
	}

}
