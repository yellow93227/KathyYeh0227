package ex02;
public class Ex02_T03 {
	public static void main(String[] args) {
		byte num = 127;
		num++;
		System.out.println(num);
		System.out.println(1.0 / 3.0);
		System.out.println(1.0f / 3.0f);
	}
}
