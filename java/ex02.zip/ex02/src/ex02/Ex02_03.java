package ex02;
public class Ex02_03 {
	public static void main(String[] args) {
		final String bookName = "Java基礎必修課";
		final int price = 540;
		int num =2;
		System.out.println(bookName + num + "本總計：" + (price*num) + "元");
	}
}
