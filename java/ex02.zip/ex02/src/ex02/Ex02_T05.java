package ex02;
public class Ex02_T05 {
	public static void main(String[] args) {
		double d = 2.567;;
		int i = 0;
		i = (int)d;
		System.out.printf("i 變數值為 %d%n", i);
	}
}
