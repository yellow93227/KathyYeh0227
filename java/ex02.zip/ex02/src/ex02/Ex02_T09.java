package ex02;

public class Ex02_T09 {

	public static void main(String[] args) {
		int a = 7;
		int b = 5;
		String val1 = "a + b = " + a + b;
		System.out.println(val1);
		String val2 = "a + b = " + (a + b);
		System.out.println(val2);
	}

}
