package ex02;
public class Ex02_01 {
	public static void main(String[] args) {
		System.out.println("  十進制 10 -> " + 10);    // 十進制10
		System.out.println("  二進制 10 -> " + 0b10);  // 二進制10轉十進制
		System.out.println("  八進制 10 -> " + 010);   // 八進制10轉十進制
		System.out.println("十六進制 10 -> " + 0x10);  // 十六進制10轉十進制

	}
}
