package ex02;
public class Ex02_07 {
	public static void main(String[] args) {
		int a = 10, b = 3;
		System.out.println("a = " + a + ", b = " + b);
		boolean c = a < b;
		System.out.println("a < b = " + c);
		c = a > b;
		System.out.println("a > b = " + c);
		c = (a == b);
		System.out.println("a == b = " + c);
	}
}
