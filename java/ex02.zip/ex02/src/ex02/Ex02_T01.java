package ex02;
public class Ex02_T01 {
	public static void main(String[] args) {
		int a = 50;
		a += 100 % 5 + 10 * 2;
		System.out.println("a = " + a );
	}
}
