package ex02;

public class Ex02_T08 {

	public static void main(String[] args) {
		double d = 30;
		d %= -3d;
		System.out.println(d);
		d += 10f;
		System.out.println(d);
		d *= -4;
		System.out.println(d);
		
	}

}
